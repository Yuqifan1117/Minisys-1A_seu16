#ifndef FORM_H
#define FORM_H

#include <QWidget>

class QLineEdit;
namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();
    int argnum;

private slots:
    void on_pushButton_clicked();

    void on_buttonBox_accepted();

    void on_lineEdit_editingFinished();

private:
    Ui::Form *ui;
    QLineEdit *lineEdit=new QLineEdit;

};

#endif // FORM_H
