/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtWidgets>

#include "mainwindow.h"
#include "form.h"
#include<qmessagebox.h>
//! [0]
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupFileMenu();
    setupHelpMenu();
    setupRunMenu();
    setupEditor();

    setCentralWidget(editor);
    setWindowTitle(tr("MyIDE"));

}

//! [0]

void MainWindow::about()
{
    QMessageBox::about(this, tr("About MyIDE"),
                tr("<p>Presented by <b>Cao Zheyu </p>"));

}

void MainWindow::newFile()
{
    editor->clear();
}

void MainWindow::openFile(const QString &path)
{
    fileName = path;
    if (fileName.isNull())
        fileName = QFileDialog::getOpenFileName(this, tr("Open File"), "", " Files (*.cpp *.h *.txt)");

    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QFile::ReadOnly | QFile::Text))
            editor->setPlainText(file.readAll());
    }
}
void MainWindow::saveFile()
{
    QString savePath=QFileDialog::getSaveFileName(this,tr("选择保存路径与文件名"),fileName,tr("Cpp File(*.cpp *.c *.h)"));
    if(!savePath.isEmpty()){
        QFile out(savePath);
        out.open(QIODevice::WriteOnly|QIODevice::Text);
        QTextStream str(&out);
        str<<editor->toPlainText();
        out.close();
        //fileSaved=true;
        QRegularExpression re(tr("(?<=\\/)\\w+\\.cpp|(?<=\\/)\\w+\\.c|(?<=\\/)\\w+\\.h|(?<=\\/)\\w+\\.txt"));
        fileName=re.match(savePath).captured();
        filePath=savePath;
        this->setWindowTitle(tr("MyIDE - ")+fileName);
      }

}

//! [1]
void MainWindow::setupEditor()
{
    QFont font;
    font.setFamily("Courier");
    font.setFixedPitch(true);
    font.setPointSize(10);

    editor = new QTextEdit;
    editor->setFont(font);

    highlighter = new Highlighter(editor->document());

    QFile file("mainwindow.h");
    if (file.open(QFile::ReadOnly | QFile::Text))
        editor->setPlainText(file.readAll())  ;
}
//! [1]

void MainWindow::setupHelpMenu()
{
    QMenu *fileMenu = new QMenu(tr("&Help"), this);
    menuBar()->addMenu(fileMenu);

    fileMenu->addAction(tr("&开发人员"), this,
                        &MainWindow::about);
}
void MainWindow::compileFile()
{
//    QString cmd = "/Applications/NeteaseMusic.app";


//    QProcess m_process;
//    m_process.setProcessChannelMode(QProcess::MergedChannels);
//    connect(m_process , &QProcess::readyReadStandardOutput , this , &MainWindow::onOut);
//    m_process.start(cmd);

//    if (!m_process->waitForStarted()) {
//        qDebug() << "start failed:" << m_process->errorString();
//    } else {
//        qDebug() << "start success:";
//    }




    QProcess p(0);

    QString command ="D:\\Project1.exe";//编译的程序

    QString filenameforcompile;
    filenameforcompile = QFileDialog::getOpenFileName(this, tr("Open File"), "", " Files (*.c)");

    QStringList args;
    filenameforcompile= QDir::toNativeSeparators(filenameforcompile);
    args.append(filenameforcompile);

    qDebug()<<args;

    p.startDetached(command,args);//command是要执行的命令,args是参数
    //p.waitForFinished();
    qDebug()<<QString::fromLocal8Bit(p.readAllStandardError());

    Sleep(2000);
    QString fileName="C:\\Users\\dell-pc\\Documents\\Tencent Files\\996324825\\FileRecv\\syntaxhighlighter\\error.log";

    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QFile::ReadOnly | QFile::Text))
        {
            QString str=file.readAll();
            editor->setPlainText(str);
        }
    }
    else {
        printf("kong\n");
        fflush(stdout);
    }
    printf("compile done\n");
    fflush(stdout);
}

void MainWindow::AssembleFile()
{

    //调用汇编接口
    QProcess p(0);

    QString command ="D:\\Assembler.exe";//汇编的程序

    QString filenameforcompile;
    filenameforcompile = QFileDialog::getOpenFileName(this, tr("Open File"), "", " Files (*.asm)");

    QStringList args;
    filenameforcompile= QDir::toNativeSeparators(filenameforcompile);
    args.append(filenameforcompile);

    qDebug()<<args;

    p.startDetached(command,args);//command是要执行的命令,args是参数
   // p.waitForFinished();
    qDebug()<<QString::fromLocal8Bit(p.readAllStandardError());

    Sleep(2000);
    QString fileName="C:\\Users\\dell-pc\\Documents\\Tencent Files\\996324825\\FileRecv\\syntaxhighlighter\\Asmlog.txt";

    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QFile::ReadOnly | QFile::Text))
        {
            QString str=file.readAll();
            editor->setPlainText(str);
        }
    }
    else {
        printf("kong\n");
        fflush(stdout);
    }

    printf("Assemble done\n");
    fflush(stdout);
}
void MainWindow::linkFile()
{

    QProcess p(0);

    QString command ="D:\\linker.exe";


    QStringList filenameforlink;
        filenameforlink = QFileDialog::getOpenFileNames(this, tr("Open File"), "", " Files (*.o *.l)");

         QStringList args;
    for(int i=0;i<filenameforlink.length();i++)
   {
        QString mystring = QDir::toNativeSeparators(filenameforlink.at(i));
        args.append(mystring);

    }
    qDebug()<<args;

    p.startDetached(command,args);//command是要执行的命令,args是参数
//    p.waitForFinished();


    Sleep(2000);
    QTextCodec *codec = QTextCodec::codecForName("GBK");

    QString fileName="C:\\Users\\dell-pc\\Documents\\Tencent Files\\996324825\\FileRecv\\syntaxhighlighter\\log.txt";
    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QFile::ReadOnly | QFile::Text))
        {
            printf("k\n");
            fflush(stdout);
            QString str=codec->toUnicode(file.readAll());
            editor->setPlainText(str);
        }
    }
    else {
        printf("kong\n");
        fflush(stdout);

    }



}

void MainWindow::setupRunMenu()
{

    QMenu *runMenu = new QMenu(tr("&Run"), this);
    menuBar()->addMenu(runMenu);
    runMenu->addAction(tr("&编译"), this,
                        &MainWindow::compileFile);
    runMenu->addAction(tr("&汇编"), this,
                        &MainWindow::AssembleFile);
    runMenu->addAction(tr("&链接"), this,
                        &MainWindow::linkFile);

}
void MainWindow::setupFileMenu()
{
    QMenu *fileMenu = new QMenu(tr("&文件"), this);
    menuBar()->addMenu(fileMenu);

    fileMenu->addAction(tr("&新建"), this,
                        &MainWindow::newFile, QKeySequence::New);
    fileMenu->addAction(tr("&打开..."),
                        this, [this](){ openFile(); }, QKeySequence::Open);
    fileMenu->addAction(tr("&保存..."),
                        this, [this](){ saveFile(); }, QKeySequence::Save);

}
