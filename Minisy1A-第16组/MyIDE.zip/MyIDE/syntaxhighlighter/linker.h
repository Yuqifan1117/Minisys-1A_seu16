#ifndef LINKER_H
#define LINKER_H

#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <fstream>
#include "dataHelper.h"
using namespace std;

extern string logStr;
extern void exitFile();

class Linker {
public:
    Linker();
    Linker(int,vector<string>,string);
    ~Linker();
    bool SymbolResolution();//符号解析
    bool DefSymRelocation();//定义符号重定位
    bool QuoteSymRelocation();//引用符号重定位
    bool ChangeValToBin(char*, unsigned int, unsigned int, long int);//将地址转换为字符串并写入
    string Binarycout(long int, int);//地址转换为2进制
    bool ChangeBinToCOE();//将二进制代码转为coe格式
    bool MakeLibFile(vector<string>, string);//制作库文件
private:
    int fileNum;//需要链接的文件数
    vector<string> fileName;//各个文件名称
    vector<vector<Elf32_Shdr>> allShdr;//各文件对应节头表
    string outputFile;//输出文件名
    string intermediateFile;//中间文件名(存储未转换为coe格式的二进制文件)
    string intermediateFileData;//中间文件名(存储未转换为coe格式的二进制数据文件)
    vector<string> E;//组成可执行文件的所有目标文件集合
    map<string,Elf32_Sym> U;//未解析符号集合
    map<string,Elf32_Sym> D;//已定义符号集合
    map<int, unsigned int> libFileOffset;//记录库文件对应目标文件的偏移
};
#endif // LINKER_H
