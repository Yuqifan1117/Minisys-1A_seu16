#include"linker.h"
using namespace std;

void exitFile() {
    ofstream log;//输出日志
    log.open("log.txt", ios::out);
    log << logStr;
    log.close();
    exit(1);
}

Linker::Linker() {
    fileNum = 0;
    fileName.clear();
    intermediateFile = "interFile.b";
    intermediateFileData = "interFileData.b";
    outputFile = "empty.coe";
    E.clear();//清空符号解析集合
    U.clear();
    D.clear();
}
Linker::Linker(int num,vector<string> name,string output) {
    fileNum = num;
    fileName = name;
    intermediateFile = "interFile.b";
    intermediateFileData = "interFileData.b";
    outputFile = output;
    E.clear();
    U.clear();
    D.clear();
    //for (int i = 0; i < num; i++)
        //cout << fileName[i] << " ";
}
Linker::~Linker() {

}
bool Linker::SymbolResolution() {
    ifstream inputFile;
    string theFile = "";
    unsigned long symBegin;
    unsigned long strtabBegin;
    unsigned int jumpPtr;
    char* saveptr = NULL;
    unsigned int theOffset = 0;
    string suffix;
    int lack = 0;
    for (int i = 0; i < fileNum; i++)
    {
        vector<Elf32_Shdr> fileShdr;
        theFile = fileName[i];
        char temp[100] = {};
        strcpy_s(temp, strlen(theFile.c_str()) + 1, theFile.c_str());
        strtok_s(temp, ".", &saveptr);
        suffix = saveptr;//截取文件名后缀
        if (suffix == "l") {//该文件是库文件
            if (i < fileNum - lack) {
                cout << theFile << "分析库文件\n";
                inputFile.open(theFile, ios::in);
                if (!inputFile.is_open())//判断文件是否成功打开
                {
                    logStr += "Error opening inputfile:";
                    logStr += theFile;
                    logStr += "\n";
                    cout << "Error opening inputfile" << endl;
                    exitFile();
                }
                unsigned int libHeadOffset;
                if (!inputFile.eof()) {
                    inputFile >> libHeadOffset;//读入库文件头部偏移
                }
                else {
                    logStr += theFile;
                    logStr+= "库文件头部偏移格式错误\n";
                    cout << theFile << "库文件头部偏移格式错误\n";
                    exitFile();
                }
                inputFile.seekg(libHeadOffset);
                int libObjNum = 0;
                if (!inputFile.eof()) {
                    inputFile >> libObjNum;//读入库文件包括的目标文件数
                    cout << libObjNum << endl;
                }
                else {
                    logStr += theFile;
                    logStr += "库文件目标文件数格式错误\n";
                    cout << theFile << "库文件目标文件数格式错误\n";
                    exitFile();
                }
                for (int j = 0; j < libObjNum; j++) {
                    int libSymNum;
                    string libName;
                    unsigned int libOffset;
                    if (!inputFile.eof()) {//读入目标文件名
                        inputFile >> libName;
                        cout << "库中文件 " << libName << endl;
                    }
                    else {
                        cout << theFile << "库文件目标文件名格式错误\n";
                        exitFile();
                    }
                    if (!inputFile.eof()) {//读入目标文件名
                        inputFile >> libOffset;
                        cout << "库中文件偏移 " << libOffset << endl;
                    }
                    else {
                        logStr += theFile;
                        logStr += "库文件目标文件偏移格式错误\n";
                        cout << theFile << "库文件目标文件偏移格式错误\n";
                        exitFile();
                    }
                    if (!inputFile.eof()) {//读入目标文件已定义符号数
                        inputFile >> libSymNum;
                    }
                    else {
                        logStr += theFile;
                        logStr += "库文件目标文件已定义符号数格式错误\n";
                        cout << theFile << "库文件目标文件已定义符号数格式错误\n";
                        exitFile();
                    }
                    for (int k = 0; k < libSymNum; k++) {
                        string libSymName;
                        map<string, Elf32_Sym>::iterator iter;
                        if (!inputFile.eof()) {//读入已定义符号名
                            inputFile >> libSymName;
                        }
                        else {
                            logStr += theFile;
                            logStr += "库文件已定义符号格式错误\n";
                            cout << theFile << "库文件已定义符号格式错误\n";
                            exitFile();
                        }
                        iter = U.find(libSymName);
                        if (iter != U.end()) {//该目标文件中含有未定义的符号，将该文件加入要解析的目标文件队列末尾，目标文件数+1
                            fileName.push_back(theFile);
                            fileNum++;
                            //fileOffset.push_back(libOffset);
                            libFileOffset.insert(pair<int, unsigned int>(fileNum - 2, libOffset));
                            lack++;
                        }
                    }
                }
                inputFile.close();
                fileName.erase(fileName.begin() + i);//库文件解析完成，删除库文件，并恢复指针指向下一目标文件
                i--;
                fileNum--;
                continue;//开始解析下一目标文件
            }
            else {
                map<int, unsigned int>::iterator iter;
                iter = libFileOffset.find(i);
                if (iter != libFileOffset.end()) {
                    theOffset = iter->second;
                }
                else {
                    logStr += theFile;
                    logStr += "库文件出错\n";
                    cout << "库文件出错\n";
                    exitFile();
                }

            }
        }
        else {
            theOffset = 0;
        }
        inputFile.open(theFile, ios::in);
        if (!inputFile.is_open())//判断文件是否成功打开
        {
            logStr += "Error opening inputfile:";
            logStr += theFile;
            logStr += "\n";
            cout << "Error opening inputfile" << endl;
            exitFile();
        }
        inputFile.seekg(theOffset);
        inputFile >> jumpPtr;
        inputFile.seekg(jumpPtr + theOffset, ios::beg);//表头为一个定长数据项，指示文件末尾节头表的偏移，以方便计算各节偏移
        for (int j = 0; j < 8; j++) {//读取节头表信息，一共8个节
            Elf32_Shdr* Shdr = new Elf32_Shdr;
            if (!inputFile.eof()) {
                inputFile >> Shdr->sh_name;
                cout << "name " << Shdr->sh_name << endl;
            }
            else
            {
                logStr += theFile;
                logStr += "节头表字符串表索引格式错误\n";
                cout << theFile << endl;
                cout << "节头表字符串表索引格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Shdr->sh_offset;
                cout << "offset " << Shdr->sh_offset << endl;
            }
            else
            {
                logStr += theFile;
                logStr += "节头表节偏移格式错误\n";
                cout << theFile << endl;
                cout << "节头表节偏移格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Shdr->sh_size;
                cout << "size " << Shdr->sh_size << endl;
            }
            else
            {
                logStr += theFile;
                logStr += "节头表节长度格式错误\n";
                cout << theFile << endl;
                cout << "节头表节长度格式错误\n";
                exitFile();
            }
            fileShdr.push_back(*Shdr);
            cout << "节头表保存成功\n";
        }
        allShdr.push_back(fileShdr);//保存对应目标或库文件的节头表
        cout << theFile << "所有节头表保存成功\n";
        unsigned int offset = fileShdr[4].sh_offset;
        unsigned int stroffset = fileShdr[7].sh_offset;
        unsigned int size = fileShdr[4].sh_size;
        unsigned int end = offset + size + theOffset;
        unsigned int curTemp = 0;
        unsigned int strSize= fileShdr[7].sh_size;
        string symName = "";
        map<string, Elf32_Sym>::iterator iter;
        inputFile.seekg(offset + theOffset, ios::beg);//跳转到文件符号表位置读取符号表
        //符号解析过程
        E.push_back(fileName[i]);//将目标文件加入E中
        while (inputFile.tellg() < end - 1) {
            Elf32_Sym* Symbol = new Elf32_Sym;
            Symbol->st_character = 0;
            Symbol->fileN = i;
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_name;
                cout << "name " << Symbol->st_name << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表字符串表索引格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表字符串表索引格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表字符串表索引格式错误\n";
                cout << theFile << endl;
                cout << "符号表表字符串表索引格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_value;
                cout << "value " << Symbol->st_value << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表符号偏移格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表符号偏移格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表符号偏移格式错误\n";
                cout << theFile << endl;
                cout << "符号表表符号偏移格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_type;
                cout << "type " << Symbol->st_type << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表符号类型格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表符号类型格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表符号类型格式错误\n";
                cout << theFile << endl;
                cout << "符号表表符号类型格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_bind;
                cout << "bind " << Symbol->st_bind << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表绑定属性格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表绑定属性格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表绑定属性格式错误\n";
                cout << theFile << endl;
                cout << "符号表表绑定属性格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_other;
                cout << "other " << Symbol->st_other << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表可见性格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表可见性格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表可见性格式错误6\n";
                cout << theFile << endl;
                cout << "符号表表可见性格式错误6\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_shndx;
                cout << "shndx " << Symbol->st_shndx << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表节头表索引格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表节头表索引格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表节头表索引格式错误\n";
                cout << theFile << endl;
                cout << "符号表表节头表索引格式错误\n";
                exitFile();
            }
            if (Symbol->st_type == 2 || (Symbol->st_type == 1 && Symbol->st_other == 0))
                Symbol->st_character = 1;//函数名和已初始化的全局变量为强符号
            else if (Symbol->st_type == 1 && Symbol->st_other == 1)
                Symbol->st_character = 2;//未初始化的全局变量为弱符号
            curTemp = inputFile.tellg();//保存当前文件位置
            unsigned int strptr = Symbol->st_name + stroffset;
            if (Symbol->st_name < 0||Symbol->st_name>strSize) {
                logStr += theFile;
                logStr += "字符串表索引出错\n";
                cout << theFile << "字符串表索引出错\n";
                exitFile();
            }
            inputFile.seekg(strptr + theOffset, ios::beg);//根据索引查找符号名字
            if (!inputFile.eof())
                inputFile >> symName;
            else
            {
                logStr += theFile;
                logStr += "字符串表格式错误\n";
                cout << theFile << endl;
                cout << "字符串表格式错误\n";
                exitFile();
            }
            if (Symbol->st_other == 2) {//外部符号
                iter = D.find(symName);
                if (iter == D.end()) {
                    if (U.find(symName) == U.end()) {
                        U.insert(pair<string, Elf32_Sym>(symName, *Symbol));//为引用符号，符号在外部定义,且当前符号没有加入已定义符号集合中
                        cout << symName << "外部符号添加成功\n";
                    }
                }
                else {
                    cout << symName << "该符号已定义\n";
                }
            }
            else {//内部定义符号
                iter = D.find(symName);
                if (iter == D.end()) {
                    D.insert(pair<string, Elf32_Sym>(symName, *Symbol));//为定义符号，且已定义符号集合中没有记录
                    cout << symName << "内部符号添加成功\n";
                    iter = U.find(symName);
                    if (iter != U.end()) {
                        U.erase(iter);//U中符号已找到定义，删除U中符号
                        cout << symName << "U符号删除成功\n";
                    }
                }
                else
                {
                    if (iter->second.st_character == 1 && Symbol->st_character == 1)
                    {
                        logStr += symName;
                        logStr += "符号重定义\n";
                        cout << symName << "符号重定义\n";//强符号不能多次定义
                        exitFile();
                    }
                    else if (iter->second.st_character == 2 && Symbol->st_character == 2)
                    {
                        logStr += "警告";
                        logStr += symName;
                        logStr += "符号存在多个弱定义\n";
                        cout << "警告：" << symName << "符号存在多个弱定义\n";//有多个弱符号定义，任选其一作为定义符号（选择已存在的定义），输出一条警告
                    }
                    else if (iter->second.st_character == 2 && Symbol->st_character == 1) {
                        D.erase(iter);
                        D.insert(pair<string, Elf32_Sym>(symName, *Symbol));//原符号为弱符号，被当前强符号覆盖
                        logStr += "警告";
                        logStr += symName;
                        logStr += "符号存在多个弱定义被强定义覆盖\n";
                        cout << symName << "内部符号修改成功\n";
                    }
                    else if (iter->second.st_character == 1 && Symbol->st_character == 2) {//已有强符号，如当前为弱符号则不作修改
                        logStr += "警告";
                        logStr += symName;
                        logStr += "符号存在多个弱定义被强定义覆盖\n";
                        cout << symName << "弱符号不做修改\n";
                    }
                }
            }
            inputFile.seekg(curTemp, ios::beg);//恢复读取符号表位置
        }
        inputFile.close();
    }
    if (!U.empty())//所有文件符号解析完成，仍有未定义符号
    {
        logStr += "目标文件中存在未定义符号\n";
        cout << "目标文件中存在未定义符号\n";
        for (map <string, Elf32_Sym>::iterator iter = U.begin(); iter != U.end(); iter++) {
            logStr += iter->first;
            logStr += " ";
            cout << iter->first << " ";
        }
        logStr += "\n";
        cout << endl;
        exitFile();
    }
    cout << fileNum << " " << fileName.size() << endl;
    for (int i = 0; i < fileName.size(); i++) {
        cout << fileName[i]<<":";
        map<int, unsigned int>::iterator iter;
        iter = libFileOffset.find(i);
        if (iter != libFileOffset.end())cout << iter->second;
        cout << endl;
    }
    return true;
}

bool Linker::DefSymRelocation() {
    unsigned int vAddr;
    for (map<string, Elf32_Sym>::iterator iter = D.begin(); iter != D.end(); iter++) {
        if (iter->second.st_shndx == 0) {//该符号在.text节
            vAddr = 0;
            for (int i = 0; i < iter->second.fileN; i++) {
                vAddr += allShdr[i][0].sh_size + allShdr[i][1].sh_size;//累加之前目标文件的.text和.rodata节长度
            }
            vAddr += iter->second.st_value;//累加符号在节中的偏移
            vAddr = vAddr / 8;//将二进制地址转换为字节地址
            cout << iter->first << " " << vAddr << endl;
            iter->second.st_value=vAddr;//修改value为符号的虚拟地址
        }
        else if(iter->second.st_shndx == 1){//该符号在.rodata节
            vAddr = 0;
            for (int i = 0; i < iter->second.fileN; i++) {
                vAddr += allShdr[i][0].sh_size + allShdr[i][1].sh_size;//累加之前目标文件的.text和.rodata节长度
            }
            vAddr += allShdr[iter->second.fileN][0].sh_size;//累加该目标文件.text节长度
            vAddr += iter->second.st_value;//累加符号在节中的偏移
            vAddr = vAddr / 8;//将二进制地址转换为字节地址
            cout << iter->first << " " << vAddr << endl;
            iter->second.st_value = vAddr;//修改value为符号的虚拟地址
        }
        else if (iter->second.st_shndx == 2) {//该符号在.data节
            vAddr = 0;
            //for (int i = 0; i < fileNum; i++) {
            //	vAddr += allShdr[i][0].sh_size + allShdr[i][1].sh_size;//累加所有目标文件的.text和.rodata节长度
            //}
            for (int i = 0; i < iter->second.fileN; i++) {
                vAddr += allShdr[i][2].sh_size;//累加之前目标文件的.data节长度
            }
            vAddr += iter->second.st_value;//累加符号在节中的偏移
            vAddr = vAddr / 8;//将二进制地址转换为字节地址
            cout << iter->first << " " << vAddr << endl;
            iter->second.st_value = vAddr;//修改value为符号的虚拟地址
        }
        else if (iter->second.st_shndx == 3) {//该符号在.bss节
            vAddr = 0;
            //for (int i = 0; i < fileNum; i++) {
            //	vAddr += allShdr[i][0].sh_size + allShdr[i][1].sh_size+allShdr[i][2].sh_size;//累加所有目标文件的.text、.rodata和.data节长度
            //}
            for (int i = 0; i < fileNum; i++) {
                    vAddr += allShdr[i][2].sh_size;//累加所有目标文件的.data节长度
                }
            for (int i = 0; i < iter->second.fileN; i++) {
                vAddr += allShdr[i][3].sh_size;//累加之前目标文件的.bss节长度
            }
            vAddr += iter->second.st_value;//累加符号在节中的偏移
            vAddr = vAddr / 8;//将二进制地址转换为字节地址
            cout << iter->first << " " << vAddr << endl;
            iter->second.st_value = vAddr;//修改value为符号的虚拟地址
        }
    }
    return true;
}
bool Linker::QuoteSymRelocation() {
    ofstream toImFile;
    ofstream toImFileData;
    ifstream inputFile;
    string theFile = "";
    Elf32_Rel* Rel = new Elf32_Rel;
    unsigned int pcAddr;
    int theOffset = 0;
    long int relativeAddr;
    toImFile.open(intermediateFile, ios::out);
    if (!toImFile.is_open())//判断文件是否成功打开
    {
        logStr += "Error opening imfile:";
        logStr += intermediateFile;
        logStr += "\n";
        cout << "Error opening imfile" << endl;
        exitFile();
    }
    toImFileData.open(intermediateFileData, ios::out);
    if (!toImFileData.is_open())//判断文件是否成功打开
    {
        logStr += "Error opening imfile:";
        logStr += intermediateFileData;
        logStr += "\n";
        cout << "Error opening imfile" << endl;
        exitFile();
    }
    for (int i = 0; i < fileNum; i++) {//合并并重定位.text和.rodata节
        //cout << i << " ";
        cout << "合并重定位text节\n";
        theFile = fileName[i];
        cout << "filename:" << theFile << endl;
        inputFile.open(theFile, ios::in);
        unsigned int offset = allShdr[i][0].sh_offset;
        unsigned int size = allShdr[i][0].sh_size+ allShdr[i][1].sh_size;
        unsigned int reltextOffset = allShdr[i][5].sh_offset;
        unsigned int reltextSize = allShdr[i][5].sh_size;
        unsigned int curTemp = 0;
        char* content = new char[size+2];
        content[size] = '\0';
        content[size+1] = '\0';
        string symName;
        map<string, Elf32_Sym>::iterator iter;
        if (!inputFile.is_open())//判断文件是否成功打开
        {
            logStr += "Error opening inputfile:";
            logStr += theFile;
            logStr += "\n";
            cout << "Error opening inputfile2" << endl;
            exitFile();
        }
        char temp[100] = {};
        string suffix;
        char* saveptr = NULL;
        strcpy_s(temp, strlen(theFile.c_str()) + 1, theFile.c_str());
        strtok_s(temp, ".", &saveptr);
        suffix = saveptr;//截取文件名后缀
        if (suffix == "l") {//该文件是库文件
            map<int, unsigned int>::iterator iter;
            iter = libFileOffset.find(i);
            if (iter != libFileOffset.end()) {
                theOffset = iter->second;
            }
            else {
                logStr += theFile;
                logStr += "库文件偏移出错\n";
                cout << "库文件偏移出错\n";
                exitFile();
            }
        }
        else {
            theOffset = 0;
        }
        unsigned int end = reltextOffset + reltextSize + theOffset;
        inputFile.seekg(offset + theOffset, ios::beg);
        //while (!inputFile.eof() && inputFile.tellg() < offset + size) {
        //	string temp;
        //	inputFile.read(temp, size);
        //}
        if (size <= 0)continue;
        inputFile.read(content, size);//读取.text和.rodata节内容
        inputFile.seekg(reltextOffset + theOffset, ios::beg);//读取重定位表
        cout << "end:" << end << endl;
        cout << "tellg " << inputFile.tellg() << endl;
        while (inputFile.tellg() < end - 1) {
            if (!inputFile.eof()) {
                inputFile >> Rel->r_offset;
                cout << "r_offset " << Rel->r_offset << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "重定位表偏移格式错误\n";
                    cout << theFile << endl;
                    cout << "重定位表偏移格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "重定位表表偏移格式错误\n";
                cout << theFile << endl;
                cout << "重定位表表偏移格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Rel->r_info;
                cout << "r_info " << Rel->r_info << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "重定位表索引格式错误\n";
                    cout << theFile << endl;
                    cout << "重定位表索引格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "重定位表表索引格式错误\n";
                cout << theFile << endl;
                cout << "重定位表表索引格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Rel->r_size;
                cout << "r_size " << Rel->r_size << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "重定位表长度格式错误\n";
                    cout << theFile << endl;
                    cout << "重定位表长度格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "重定位表表长度格式错误\n";
                cout << theFile << endl;
                cout << "重定位表表长度格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Rel->r_type;
                cout << "r_type " << Rel->r_type << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "重定位表类型格式错误\n";
                    cout << theFile << endl;
                    cout << "重定位表类型格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "重定位表表类型格式错误\n";
                cout << theFile << endl;
                cout << "重定位表表类型格式错误\n";
                exitFile();
            }
            curTemp = inputFile.tellg();//保存当前读写位置
            cout << "curtemp " << curTemp << "**\n";
            unsigned int strptr = allShdr[i][7].sh_offset + Rel->r_info;
            //cout << ":::" << allShdr[i][7].sh_offset << " " << Rel->r_info << endl;
            inputFile.seekg(strptr + theOffset, ios::beg);//根据索引跳转至字符串表
            cout << "strAddr:" << strptr + theOffset << endl;
            if (!inputFile.eof()) {
                inputFile >> symName;
                cout << "symName " << symName << endl;
            }
            else
            {
                logStr += theFile;
                logStr += "字符串表格式错误\n";
                cout << theFile << endl;
                cout << "字符串表格式错误\n";
                exitFile();
            }
            iter = D.find(symName);//查找定义符号表，找到定义符号
            if (iter != D.end()) {
                pcAddr = 0;
                relativeAddr = 0;
                if (Rel->r_type == 1) {//重定位类型为绝对地址
                    ChangeValToBin(content, Rel->r_offset, Rel->r_size, iter->second.st_value);//根据重定位表修改指令
                    cout << "绝对地址：" << iter->second.st_value << endl;
                }
                else if (Rel->r_type == 2) {//重定位类型为相对地址
                    for (int j = 0; j < i; j++) {
                        pcAddr += allShdr[j][0].sh_size + allShdr[j][1].sh_size;//计算合并节的偏移
                    }
                    pcAddr += Rel->r_offset;//计算当前pc地址
                    pcAddr = pcAddr / 8 + 4;
                    relativeAddr = iter->second.st_value - pcAddr;//计算绝对地址
                    ChangeValToBin(content, Rel->r_offset, Rel->r_size, relativeAddr);//根据重定位表修改指令
                    //cout << endl << content << endl;
                    cout << "相对地址： " << relativeAddr << endl;
                }
                else {
                    logStr += theFile;
                    logStr += "无此重定位类型\n";
                    cout << "无此重定位类型\n";
                    exitFile();
                }
            }
            else {
                logStr += "找不到定义符号:";
                logStr += symName;
                logStr += "\n";
                cout << symName << "找不到定义符号1\n";
                exitFile();
            }
            inputFile.seekg(curTemp, ios::beg);//返回重定位表读取下一条重定位信息
            cout << "changecurtemp " << inputFile.tellg() << "&&\n";
        }
        //cout << endl << content << endl;
        toImFile << content;//修改后的内容写入中间文件
        //toImFile << "aaaa";//修改后的内容写入中间文件
        delete[] content;
        inputFile.close();
    }
    for (int i = 0; i < fileNum; i++) {//合并并重定位.data节
        cout << "合并重定位data节\n";
        theFile = fileName[i];
        cout << "filename: " << theFile << endl;
        inputFile.open(theFile, ios::in);
        unsigned int offset = allShdr[i][2].sh_offset;
        unsigned int size = allShdr[i][2].sh_size;
        unsigned int reldataOffset = allShdr[i][6].sh_offset;
        unsigned int reldataSize = allShdr[i][6].sh_size;
        unsigned int curTemp = 0;
        char* content = new char[size + 1];
        content[size-1] = '\0';
        content[size] = '\0';
        string symName;
        map<string, Elf32_Sym>::iterator iter;
        if (!inputFile.is_open())//判断文件是否成功打开
        {
            logStr += "Error opening inputfile:";
            logStr += theFile;
            logStr += "\n";
            cout << "Error opening inputfile2" << endl;
            exitFile();
        }
        char temp[100] = {};
        string suffix;
        char* saveptr = NULL;
        strcpy_s(temp, strlen(theFile.c_str()) + 1, theFile.c_str());
        strtok_s(temp, ".", &saveptr);
        suffix = saveptr;//截取文件名后缀
        if (suffix == "l") {//该文件是库文件
            map<int, unsigned int>::iterator iter;
            iter = libFileOffset.find(i);
            if (iter != libFileOffset.end()) {
                theOffset = iter->second;
            }
            else {
                logStr += theFile;
                logStr+= "库文件偏移出错\n";
                cout << "库文件偏移出错\n";
                exitFile();
            }
        }
        else {
            theOffset = 0;
        }
        unsigned int end = reldataOffset + reldataSize + theOffset;
        inputFile.seekg(offset + theOffset, ios::beg);
        //while (!inputFile.eof() && inputFile.tellg() < offset + size) {
        //	string temp;
        //	inputFile.read(temp, size);
        //}
        if (size <= 0)break;
        inputFile.read(content, size-1);//读取.data节内容
        inputFile.seekg(reldataOffset + theOffset, ios::beg);//读取重定位表
        cout << "end:" << end << endl;
        cout << "tellg " << inputFile.tellg() << endl;
        cout << "end:" << end << endl;
        cout << "tellg " << inputFile.tellg() << endl;
        while (inputFile.tellg() < end-1) {
            if (!inputFile.eof()) {
                inputFile >> Rel->r_offset;
                cout << "r_offset " << Rel->r_offset << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "重定位表偏移格式错误\n";
                    cout << theFile << endl;
                    cout << "重定位表偏移格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "重定位表表偏移格式错误\n";
                cout << theFile << endl;
                cout << "重定位表表偏移格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Rel->r_info;
                cout << "r_info " << Rel->r_info << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "重定位表索引格式错误\n";
                    cout << theFile << endl;
                    cout << "重定位表索引格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "重定位表表索引格式错误\n";
                cout << theFile << endl;
                cout << "重定位表表索引格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Rel->r_size;
                cout << "r_size " << Rel->r_size << endl;
                //cout << Rel->r_size << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "重定位表长度格式错误\n";
                    cout << theFile << endl;
                    cout << "重定位表长度格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "重定位表表长度格式错误\n";
                cout << theFile << endl;
                cout << "重定位表表长度格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Rel->r_type;
                cout << "r_type " << Rel->r_type << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "重定位表类型格式错误\n";
                    cout << theFile << endl;
                    cout << "重定位表类型格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "重定位表表类型格式错误\n";
                cout << theFile << endl;
                cout << "重定位表表类型格式错误\n";
                exitFile();
            }
            curTemp = inputFile.tellg();//保存当前读写位置
            unsigned int strptr = allShdr[i][7].sh_offset + Rel->r_info;
            inputFile.seekg(strptr + theOffset, ios::beg);//根据索引跳转至字符串表
            if (!inputFile.eof())
                inputFile >> symName;
            else
            {
                logStr += theFile;
                logStr += "字符串表格式错误\n";
                cout << theFile << endl;
                cout << "字符串表格式错误\n";
                exitFile();
            }
            iter = D.find(symName);//查找定义符号表，找到定义符号
            if (iter != D.end()) {
                pcAddr = 0;
                relativeAddr = 0;
                if (Rel->r_type == 1) {
                    ChangeValToBin(content, Rel->r_offset, Rel->r_size, iter->second.st_value);//根据重定位表修改指令
                    cout << "绝对地址： " << iter->second.st_value << endl;
                }
                else if (Rel->r_type == 2) {//重定位类型为相对地址
                    for (int j = 0; j < fileNum; j++) {
                        pcAddr += allShdr[j][0].sh_size + allShdr[j][1].sh_size;
                    }
                    for (int j = 0; j < i; j++) {
                        pcAddr += allShdr[j][2].sh_size;//计算合并节的偏移
                    }
                    pcAddr += Rel->r_offset;//计算当前pc地址
                    pcAddr = pcAddr / 8 + 4;
                    relativeAddr = iter->second.st_value - pcAddr;//计算绝对地址
                    ChangeValToBin(content, Rel->r_offset, Rel->r_size, relativeAddr);//根据重定位表修改指令
                    //cout << endl << content << endl;
                    cout << "相对地址： " << relativeAddr << endl;
                }
                else {
                    logStr += theFile;
                    logStr += "无此重定位类型\n";
                    cout << "无此重定位类型\n";
                    exitFile();
                }
            }
            else {
                logStr += "找不到定义符号:";
                logStr += symName;
                logStr += "\n";
                cout << symName << "找不到定义符号\n";
                exitFile();
            }
            inputFile.seekg(curTemp, ios::beg);//返回重定位表读取下一条重定位信息
            cout << "&&" << inputFile.tellg() << "&&\n";
        }
        toImFileData << content;//修改后的内容写入中间文件
        delete[] content;
        inputFile.close();

        //因为bss节为未初始化数据，所以无内容，又因为bss节在文件末尾，coe文件自动补齐，所以无需显示写入

    }
    /*
    for (int i = 0; i < fileNum; i++) {//合并并重定位.bss节
        theFile = fileName[i];
        cout << theFile << endl;
        inputFile.open(theFile, ios::in);
        unsigned int offset = allShdr[i][3].sh_offset;
        unsigned int size = allShdr[i][3].sh_size;
        unsigned int reldataOffset = allShdr[i][6].sh_offset;
        unsigned int reldataSize = allShdr[i][6].sh_size;
        unsigned int end = reldataOffset + reldataSize;
        unsigned int curTemp = 0;
        char* content = new char[size + 1];
        string symName;
        map<string, Elf32_Sym>::iterator iter;
        if (!inputFile.is_open())//判断文件是否成功打开
        {
            cout << "Error opening inputfile2" << endl;
            return false;
        }
        //inputFile.seekg(offset, ios::beg);
        //while (!inputFile.eof() && inputFile.tellg() < offset + size) {
        //	string temp;
        //	inputFile.read(temp, size);
        //}
        //inputFile.read(content, size);//读取.data节内容
        for (int j = 0; j < size; j++)content[j] = '0';
        content[size] = '\0';//bss未初始化变量无内容，置全0
        inputFile.seekg(reldataOffset, ios::beg);//读取重定位表
        while (inputFile.tellg() < end-1) {
            if (!inputFile.eof()) {
                inputFile >> Rel->r_offset;
                cout << Rel->r_offset << endl;
                if (inputFile.tellg() > end) {
                    cout << theFile << endl;
                    cout << "重定位表格式错误\n";
                    exit(1);
                }
            }
            else
            {
                cout << theFile << endl;
                cout << "重定位表表格式错误\n";
                exit(1);
            }
            if (!inputFile.eof()) {
                inputFile >> Rel->r_info;
                cout << Rel->r_info << endl;
                if (inputFile.tellg() > end) {
                    cout << theFile << endl;
                    cout << "重定位表格式错误\n";
                    exit(1);
                }
            }
            else
            {
                cout << theFile << endl;
                cout << "重定位表表格式错误\n";
                exit(1);
            }
            if (!inputFile.eof()) {
                inputFile >> Rel->r_type;
                cout << Rel->r_type << endl;
                if (inputFile.tellg() > end) {
                    cout << theFile << endl;
                    cout << "重定位表格式错误\n";
                    exit(1);
                }
            }
            else
            {
                cout << theFile << endl;
                cout << "重定位表表格式错误\n";
                exit(1);
            }
            curTemp = inputFile.tellg();//保存当前读写位置
            cout << "***"<< curTemp << endl;
            unsigned int strptr = allShdr[i][7].sh_offset + Rel->r_info;
            inputFile.seekg(strptr, ios::beg);//根据索引跳转至字符串表
            if (!inputFile.eof())
                inputFile >> symName;
            else
            {
                cout << theFile << endl;
                cout << "字符串表格式错误\n";
                exit(1);
            }
            iter = D.find(symName);//查找定义符号表，找到定义符号
            if (iter != D.end()) {
                if (iter->second.st_other == 1)//是.bss节内容而不是.data节内容
                    ChangeValToBin(content, Rel->r_offset, iter->second.st_size, iter->second.st_value);//根据重定位表修改指令
            }
            else {
                cout << symName << "找不到定义符号3\n";
                exit(1);
            }
            inputFile.seekg(curTemp, ios::beg);//返回重定位表读取下一条重定位信息
            cout << "&&" << inputFile.tellg() << "&&\n";
        }
        cout << theFile << "!" << endl;
        toImFile << content;//修改后的内容写入中间文件
        delete[] content;
        inputFile.close();
    }*/
    //toImFile << "\b";//输出退格符以取出文件末尾空格
    //toImFileData << "\b";
    toImFile.close();
    toImFileData.close();
    return true;
}


string Linker::Binarycout(long int n,int num)
{
    int i;
    int diff;
    string temp = "";
    string result = "";
    for (i = 31; i >= 0; i--)
    {
        if ((n >> i) & 1) {
            temp += '1';
            //cout << 1;
        }
        else {
            temp += '0';
            //cout << 0;
        }
    }
    //cout << endl << temp << endl;
    temp += '\0';
    if (num < 32) {
        diff = 32 - num;
        for (int j = 0; j < diff; j++) {//损失数据，报错
            if (n >= 0 && temp[j] == '1') {
                logStr+= "地址超出变量字节范围\n";
                cout << "地址超出变量字节范围\n";
                exitFile();
            }
            if (n < 0 && temp[j] == '0') {
                logStr += "地址超出变量字节范围\n";
                cout << "地址超出变量字节范围\n";
                exitFile();
            }
        }
        for (int j = diff; j < 32; j++) {
            result += temp[j];
        }
    }
    else if (num > 32) {
        diff = num - 32;
        for (int j = 0; j < diff; j++) {//补零
            result += '0';
        }
        for (int j = diff; j < 32; j++) {
            result += temp[j];
        }
    }
    else {//位数相等
        result = temp;
    }
    result += '\0';
    return result;
}

bool Linker::ChangeValToBin(char* source, unsigned int begin, unsigned int size, long int Val) {
    string result=Binarycout(Val,size);
    for (int i = 0; i < size ; i++) {
        source[begin + i] = result[i];
        //cout << source[begin + i];
    }
    //cout << endl << source << endl;
    return true;
}
bool Linker::ChangeBinToCOE() {
    ifstream ImFile;
    ifstream ImFileData;
    ofstream oFile;
    ofstream DataFile1;
    ofstream DataFile2;
    ofstream DataFile3;
    ofstream DataFile4;
    string compareWord;
    int count = 0;
    //char* word = new char[5];
    char temp;
    char* word = new char[5];
    bool end = false;
    ImFile.open(intermediateFile, ios::in);
    oFile.open(outputFile, ios::out);
    if (!ImFile.is_open())//判断文件是否成功打开
    {
        logStr += "Error opening imfile:";
        logStr += intermediateFile;
        logStr += "\n";
        cout << "Error opening imfile" << endl;
        exitFile();
    }
    if (!oFile.is_open())//判断文件是否成功打开
    {
        logStr += "Error opening outputfile:";
        logStr += outputFile;
        logStr += "\n";
        cout << "Error opening outputfile" << endl;
        exitFile();
    }
    oFile << "memory_initialization_radix = 16;\n";
    oFile << "memory_initialization_vector = \n";
    while (!ImFile.eof()) {
        if (count == 8) {
            oFile << "\n";
            count = 0;
        }
        for (int i = 0; i < 4; i++) {
            word[i] = '0';
        }
        word[4] = '\0';
        //for (int i = 0; i < 4; i++) {
        //	temp=ImFile.get();
        //	if (temp != ' ')compareWord[i] = temp;//跳过文件末尾空字符
        //	else end = true;
        //}
        ImFile.read(word, 4);
        if (ImFile.fail()) {
            break;
        }
        compareWord = word;
        //if (end)break;//已到达文件末尾
        if (compareWord == "0000")oFile << '0';//将二进制转换为16进制
        else if (compareWord == "0001")oFile << '1';
        else if (compareWord == "0010")oFile << '2';
        else if (compareWord == "0011")oFile << '3';
        else if (compareWord == "0100")oFile << '4';
        else if (compareWord == "0101")oFile << '5';
        else if (compareWord == "0110")oFile << '6';
        else if (compareWord == "0111")oFile << '7';
        else if (compareWord == "1000")oFile << '8';
        else if (compareWord == "1001")oFile << '9';
        else if (compareWord == "1010")oFile << 'a';
        else if (compareWord == "1011")oFile << 'b';
        else if (compareWord == "1100")oFile << 'c';
        else if (compareWord == "1101")oFile << 'd';
        else if (compareWord == "1110")oFile << 'e';
        else if (compareWord == "1111")oFile << 'f';
        count++;
        if (count == 8) {//8个一组输出，号
            oFile << ",";
        }
    }
    //oFile << "\b";
    ImFile.close();
    oFile.close();
    char tempChr='\0';
    int chooseFile = 0;
    count = 0;
    ImFileData.open(intermediateFileData, ios::in);
    DataFile1.open("data1.coe",ios::out);
    DataFile2.open("data2.coe", ios::out);
    DataFile3.open("data3.coe", ios::out);
    DataFile4.open("data4.coe", ios::out);
    if (!ImFileData.is_open())//判断文件是否成功打开
    {
        cout << "Error opening imfile" << endl;
        exitFile();
    }
    if (!DataFile1.is_open())//判断文件是否成功打开
    {
        logStr += "Error opening dataFile1:";
        logStr += "data1.coe";
        logStr += "\n";
        cout << "Error opening Data1" << endl;
        exitFile();
    }
    if (!DataFile2.is_open())//判断文件是否成功打开
    {
        logStr += "Error opening dataFile2:";
        logStr += "data2.coe";
        logStr += "\n";
        cout << "Error opening Data2" << endl;
        exitFile();
    }
    if (!DataFile3.is_open())//判断文件是否成功打开
    {
        logStr += "Error opening dataFile3:";
        logStr += "data3.coe";
        logStr += "\n";
        cout << "Error opening Data3" << endl;
        exitFile();
    }
    if (!DataFile4.is_open())//判断文件是否成功打开
    {
        logStr += "Error opening dataFile4:";
        logStr += "data4.coe";
        logStr += "\n";
        cout << "Error opening Data4" << endl;
        exitFile();
    }
    DataFile1 << "memory_initialization_radix = 16;\n";
    DataFile1 << "memory_initialization_vector = \n";
    DataFile2 << "memory_initialization_radix = 16;\n";
    DataFile2 << "memory_initialization_vector = \n";
    DataFile3 << "memory_initialization_radix = 16;\n";
    DataFile3 << "memory_initialization_vector = \n";
    DataFile4 << "memory_initialization_radix = 16;\n";
    DataFile4 << "memory_initialization_vector = \n";
    while (!ImFileData.eof()) {
        if (count == 2) {
            count = 0;
        }
        for (int i = 0; i < 4; i++) {
            word[i] = '0';
        }
        word[4] = '\0';
        //for (int i = 0; i < 4; i++) {
        //	temp=ImFile.get();
        //	if (temp != ' ')compareWord[i] = temp;//跳过文件末尾空字符
        //	else end = true;
        //}
        ImFileData.read(word, 4);
        if (ImFileData.fail()) {
            break;
        }
        compareWord = word;
        //if (end)break;//已到达文件末尾
        if (compareWord == "0000")tempChr = '0';//将二进制转换为16进制
        else if (compareWord == "0001")tempChr = '1';
        else if (compareWord == "0010")tempChr = '2';
        else if (compareWord == "0011")tempChr = '3';
        else if (compareWord == "0100")tempChr = '4';
        else if (compareWord == "0101")tempChr = '5';
        else if (compareWord == "0110")tempChr = '6';
        else if (compareWord == "0111")tempChr = '7';
        else if (compareWord == "1000")tempChr = '8';
        else if (compareWord == "1001")tempChr = '9';
        else if (compareWord == "1010")tempChr = 'a';
        else if (compareWord == "1011")tempChr = 'b';
        else if (compareWord == "1100")tempChr = 'c';
        else if (compareWord == "1101")tempChr = 'd';
        else if (compareWord == "1110")tempChr = 'e';
        else if (compareWord == "1111")tempChr = 'f';
        else {
            cout << "error in change data to coe\n";
            exitFile();
        }
        count++;
        switch (chooseFile) {
        case 0:
            DataFile1 << tempChr;
            break;
        case 1:
            DataFile2 << tempChr;
            break;
        case 2:
            DataFile3 << tempChr;
            break;
        case 3:
            DataFile4 << tempChr;
            break;
        default:
            cout << "error in write datafile\n";
            exitFile();
        }
        if (count == 2) {//2个一组输出，号
            switch (chooseFile) {
            case 0:
                DataFile1 << ",\n";
                chooseFile = (chooseFile + 1) % 4;
                break;
            case 1:
                DataFile2 << ",\n";
                chooseFile = (chooseFile + 1) % 4;
                break;
            case 2:
                DataFile3 << ",\n";
                chooseFile = (chooseFile + 1) % 4;
                break;
            case 3:
                DataFile4 << ",\n";
                chooseFile = (chooseFile + 1) % 4;
                break;
            default:
                cout << "error in write datafile\n";
                exitFile();
            }
        }
    }
    ImFileData.close();
    DataFile1.close();
    DataFile2.close();
    DataFile3.close();
    DataFile4.close();
    return true;
}

bool Linker::MakeLibFile(vector<string>ofileName, string outName) {
    ifstream inputFile;
    ofstream outputFile;
    string theFile = "";
    unsigned long symBegin;
    unsigned long strtabBegin;
    unsigned int jumpPtr;
    char* saveptr = NULL;
    char temp;
    string suffix;
    unsigned int allOffset = 0;
    vector<unsigned int> fileOffset;
    outputFile.open(outName, ios::out);
    if (!outputFile.is_open())//判断文件是否成功打开
    {
        logStr += "Error opening outputFile:";
        logStr += outName;
        logStr += "\n";
        cout << "Error opening outputfile" << endl;
        exitFile();
    }
    allOffset += 12;//文件头长度
    for (int i = 0; i < ofileName.size(); i++) {
        theFile = ofileName[i];
        inputFile.open(theFile, ios::in);
        if (!inputFile.is_open())//判断文件是否成功打开
        {
            logStr += "Error opening inputFile:";
            logStr += theFile;
            logStr += "\n";
            cout << "Error opening inputfile" << endl;
            exitFile();
        }
        fileOffset.push_back(allOffset);//记录每个文件的偏移
        inputFile.seekg(0, ios::end);
        allOffset += inputFile.tellg();//计算文件总偏移
        allOffset += 1;//加上空格长度
        inputFile.close();
    }
    string head = to_string(allOffset);
    for (int i = 0; i < 11-head.length(); i++) {
        outputFile << 0;
    }
    outputFile << head;
    outputFile << ' ';//输出文件头部的偏移，并恒定位数为12
    for (int i = 0; i < ofileName.size(); i++) {
        theFile = ofileName[i];
        inputFile.open(theFile, ios::in);
        if (!inputFile.is_open())//判断文件是否成功打开
        {
            logStr += "Error opening inputFIle:";
            logStr += theFile;
            logStr += "\n";
            cout << "Error opening inputfile" << endl;
            exitFile();
        }
        while (!inputFile.eof()) {
            inputFile.get(temp);
            if (inputFile.fail()) {
                break;
            }
            outputFile << temp;
        }
        outputFile << ' ';//空格分隔两个文件
        inputFile.close();
    }
    outputFile << ofileName.size() << endl;
    for (int i = 0; i < ofileName.size(); i++)
    {
        int num = 0;
        vector<string> defSymName;
        defSymName.clear();
        vector<Elf32_Shdr> fileShdr;
        theFile = ofileName[i];
        cout << theFile << endl;
        char temp[100] = {};
        strcpy_s(temp, strlen(theFile.c_str()) + 1, theFile.c_str());
        strtok_s(temp, ".", &saveptr);
        suffix = saveptr;//截取文件名后缀
        if (suffix != "o") {//该文件不是目标文件
            logStr += theFile;
            logStr += "该文件不是目标文件\n";
            cout << theFile << "该文件不是目标文件\n";
            exitFile();
        }
        else cout << 1 << endl;
        cout << theFile << endl;
        inputFile.open(theFile, ios::in);
        //inputFile.open("test3.o", ios::in);
        if (!inputFile.is_open())//判断文件是否成功打开
        {
            logStr += "Error opening inputFIle:";
            logStr += theFile;
            logStr += "\n";
            cout << "Error opening inputfile" << endl;
            exitFile();
        }
        inputFile >> jumpPtr;
        inputFile.seekg(jumpPtr, ios::beg);//表头为一个定长数据项，指示文件末尾节头表的偏移，以方便计算各节偏移
        for (int j = 0; j < 8; j++) {//读取节头表信息，一共8个节
            Elf32_Shdr* Shdr = new Elf32_Shdr;
            if (!inputFile.eof()) {
                inputFile >> Shdr->sh_name;
                cout << "name " << Shdr->sh_name << endl;
            }
            else
            {
                logStr += theFile;
                logStr += "节头表字符串表索引格式错误\n";
                cout << theFile << endl;
                cout << "节头表字符串表索引格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Shdr->sh_offset;
                cout << "offset " << Shdr->sh_offset << endl;
            }
            else
            {
                logStr += theFile;
                logStr += "节头表节偏移格式错误\n";
                cout << theFile << endl;
                cout << "节头表节偏移格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Shdr->sh_size;
                cout << "size " << Shdr->sh_size << endl;
            }
            else
            {
                logStr += theFile;
                logStr += "节头表节长度格式错误\n";
                cout << theFile << endl;
                cout << "节头表节长度格式错误\n";
                exitFile();
            }
            fileShdr.push_back(*Shdr);
            cout << "节头表保存成功\n";
        }
        unsigned int offset = fileShdr[4].sh_offset;
        unsigned int stroffset = fileShdr[7].sh_offset;
        unsigned int size = fileShdr[4].sh_size;
        unsigned int end = offset + size;
        unsigned int curTemp = 0;
        unsigned int strSize= fileShdr[7].sh_size;
        string symName = "";
        map<string, Elf32_Sym>::iterator iter;
        inputFile.seekg(offset, ios::beg);//跳转到文件符号表位置读取符号表
        //符号解析过程
        while (inputFile.tellg() < end - 1) {
            Elf32_Sym* Symbol = new Elf32_Sym;
            Symbol->st_character = 0;
            Symbol->fileN = i;
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_name;
                cout << "name " << Symbol->st_name << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表字符串表索引格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表字符串表索引格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表字符串表索引格式错误\n";
                cout << theFile << endl;
                cout << "符号表表字符串表索引格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_value;
                cout << "value " << Symbol->st_value << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表偏移格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表偏移格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表偏移格式错误2\n";
                cout << theFile << endl;
                cout << "符号表表偏移格式错误2\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_type;
                cout << "type " << Symbol->st_type << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表类型格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表类型格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表类型格式错误\n";
                cout << theFile << endl;
                cout << "符号表表类型格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_bind;
                cout << "bind " << Symbol->st_bind << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表绑定属性格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表绑定属性格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表绑定属性格式错误\n";
                cout << theFile << endl;
                cout << "符号表表绑定属性格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_other;
                cout << "other " << Symbol->st_other << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表可见性格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表可见性格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表可见性格式错误\n";
                cout << theFile << endl;
                cout << "符号表表可见性格式错误\n";
                exitFile();
            }
            if (!inputFile.eof()) {
                inputFile >> Symbol->st_shndx;
                cout << "shndx " << Symbol->st_shndx << endl;
                if (inputFile.tellg() > end) {
                    logStr += theFile;
                    logStr += "符号表节头表索引格式错误\n";
                    cout << theFile << endl;
                    cout << "符号表节头表索引格式错误\n";
                    exitFile();
                }
            }
            else
            {
                logStr += theFile;
                logStr += "符号表表节头表索引格式错误\n";
                cout << theFile << endl;
                cout << "符号表表节头表索引格式错误\n";
                exitFile();
            }
            cout << Symbol->st_other << endl;
            if (Symbol->st_other == 2)
                continue;//该符号是未定义符号，跳过不作记录
            curTemp = inputFile.tellg();//保存当前文件位置
            unsigned int strptr = Symbol->st_name + stroffset;
            if (Symbol->st_name<0 || Symbol->st_name>strSize) {
                logStr += theFile;
                logStr += "字符串表格式错误\n";
                cout << theFile << "字符串表格式错误\n";
                exitFile();
            }
            inputFile.seekg(strptr, ios::beg);//根据索引查找符号名字
            if (!inputFile.eof())
                inputFile >> symName;
            else
            {
                logStr += theFile;
                logStr += "字符串表格式错误\n";
                cout << theFile << endl;
                cout << "字符串表格式错误\n";
                exitFile();
            }
            defSymName.push_back(symName);
            num++;
            inputFile.seekg(curTemp, ios::beg);//恢复读取符号表位置
        }
        outputFile << ofileName[i] << endl;
        outputFile << fileOffset[i] << endl;
        outputFile << num << endl;
        for (int j = 0; j < num; j++)
            outputFile << defSymName[j] << endl;
        inputFile.close();
    }
    outputFile.close();
    return true;
}
