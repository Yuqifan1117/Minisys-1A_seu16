#ifndef DATAHELPER_H
#define DATAHELPER_H
#pragma once
typedef unsigned int Elf32_Word;
typedef unsigned int Elf32_Addr;
typedef unsigned int Elf32_Half;

//符号表定义
typedef struct {
    Elf32_Word st_name;//符号在字符串表中的索引，及在字符串表中的字节偏移量
    Elf32_Addr st_value;//符号对应节的偏移量或虚拟地址
    int st_type;//类型，未指定0，变量1，函数2
    int st_bind;//绑定属性，本地0，全局1
    int st_other;//符号可见性,已初始化变量0，未初始化变量1，未定义符号2
    int st_shndx;//符号所在节在节头表中的索引
    int st_character;//符号强弱属性，0未知，1强，2弱
    int fileN;//符号所在文件序号
}Elf32_Sym;

//#define ELF32_ST_BIND(info) ((info)>>4)
//#define ELF32_ST_TYPE(info) ((info&0xf))
//#define ELF32_ST_INFO(bind,type) (((bind)<<4)+((type)&0xf))

//重定位表定义
typedef struct {
    Elf32_Addr r_offset;//重定位位置对应所在节的偏移量
    Elf32_Word r_info;//符号在字符串表表中的索引值
    Elf32_Word r_size;//重定位符号长度
    int r_type;//重定位类型,1绝对地址,2相对地址,相对地址计算方法为转移目标地址-pc地址，pc地址计算方法为所在节虚拟地址+重定位位置偏移+4
}Elf32_Rel;

//#define ELF32_R_SYM(info) ((info)>>8)
//#define ELF32_R_TYPE(info) ((unsigned char)(info))
//#define ELF32_R_INFO(sym,type) (((sym)<<8)+(unsigned char)(type))

//节头表定义

typedef struct {
    Elf32_Word sh_name;//节名字符串在.strtab中的偏移
    //Elf32_Word sh_type;
    //Elf32_Word sh_flags;
    //Elf32_Addr sh_addr;
    Elf32_Addr sh_offset;//在文件中的偏移，.bss无意义
    Elf32_Word sh_size;//节在文件中所占的长度
    //Elf32_Word sh_link;
    //Elf32_Word sh_info;
    //Elf32_Word sh_addralign;
    //Elf32_Word sh_entsize;
}Elf32_Shdr;


//2020.1.7完成相对绝对重定位类型，完成库文件合并及识别
//库文件仅仅保存了目标文件数、目标文件地址、文件定义符号数和定义符号名
//库文件无法处理转移了位置的目标文件等情况
//静态链接基本完成
//尚未进行较大数据量的测试
#endif // DATAHELPER_H
